var structfile__words__s =
[
    [ "index", "structfile__words__s.html#aac994698e1c11ac6c04acbc921077d94", null ],
    [ "length", "structfile__words__s.html#aaf7ee3ca909cf8b1ec09540236711201", null ],
    [ "u_flag", "structfile__words__s.html#ad503982fd12eac27ef5395a740de844d", null ],
    [ "word", "structfile__words__s.html#aab3c16292b5e49bd95f7c3d449ea9eb6", null ]
];