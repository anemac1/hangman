var searchData=
[
  ['fred',['FRED',['../play_8c.html#ab41c5ea389c93bdcab9fea2f2946eaaa',1,'play.c']]]
];
