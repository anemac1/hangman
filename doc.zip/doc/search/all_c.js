var searchData=
[
  ['wguesses',['wguesses',['../hangman_8h.html#ad2716bcb9d12d0c90a58499fea4a25dd',1,'hangman.h']]],
  ['word_5freset',['word_reset',['../file__io_8c.html#a8f26ab291d11adef8fd9454b93eeb3bf',1,'word_reset(char *filename):&#160;file_io.c'],['../file__io_8h.html#a8f26ab291d11adef8fd9454b93eeb3bf',1,'word_reset(char *filename):&#160;file_io.c']]]
];
