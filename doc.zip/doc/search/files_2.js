var searchData=
[
  ['log_2ec',['log.c',['../log_8c.html',1,'']]],
  ['log_2eh',['log.h',['../log_8h.html',1,'']]]
];
