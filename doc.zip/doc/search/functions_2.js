var searchData=
[
  ['file_5fread',['file_read',['../file__io_8c.html#ae5c168db6a34cef70cd314b05c2dd8dd',1,'file_read(char *filename, file_words_t list[]):&#160;file_io.c'],['../file__io_8h.html#ae5c168db6a34cef70cd314b05c2dd8dd',1,'file_read(char *filename, file_words_t list[]):&#160;file_io.c']]],
  ['file_5fwrite',['file_write',['../file__io_8c.html#af06d8ac4ebce5b61f72689674442e5ec',1,'file_write(char *filename, file_words_t list[], int index):&#160;file_io.c'],['../file__io_8h.html#af06d8ac4ebce5b61f72689674442e5ec',1,'file_write(char *filename, file_words_t list[], int index):&#160;file_io.c']]],
  ['find_5funused_5fwords',['find_unused_words',['../play_8c.html#a9df9f2f9b56dc55d7a9bcf0d8111343b',1,'find_unused_words(int nwords, file_words_t list[], char *filename):&#160;play.c'],['../play_8h.html#a9df9f2f9b56dc55d7a9bcf0d8111343b',1,'find_unused_words(int nwords, file_words_t list[], char *filename):&#160;play.c']]],
  ['free_5fstruct',['free_struct',['../file__io_8c.html#a19fee975550a76e4d157a36971c0f5b1',1,'free_struct(file_words_t *elem):&#160;file_io.c'],['../file__io_8h.html#ad2c71b4e09005c4b235b87fb600934f7',1,'free_struct(file_words_t *):&#160;file_io.c']]]
];
