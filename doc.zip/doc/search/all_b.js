var searchData=
[
  ['set_5ffile',['set_file',['../menu_8c.html#addd4cebbb808f9f838c4393d9597d249',1,'set_file():&#160;menu.c'],['../menu_8h.html#addd4cebbb808f9f838c4393d9597d249',1,'set_file():&#160;menu.c']]],
  ['show_5finstr',['show_instr',['../menu_8c.html#a049ea0c5d3872ee8fd5961d9d0922447',1,'show_instr():&#160;menu.c'],['../menu_8h.html#a049ea0c5d3872ee8fd5961d9d0922447',1,'show_instr():&#160;menu.c']]],
  ['show_5fmenu',['show_menu',['../menu_8c.html#af67480724089637b55a8148566870f16',1,'show_menu():&#160;menu.c'],['../menu_8h.html#af67480724089637b55a8148566870f16',1,'show_menu():&#160;menu.c']]]
];
