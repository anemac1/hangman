var indexSectionsWithContent =
{
  0: "bcdfghilmprsw",
  1: "fm",
  2: "fhlmp",
  3: "cdfglmprsw",
  4: "i",
  5: "b",
  6: "dflmw",
  7: "h"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "enums",
  6: "defines",
  7: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Enumerations",
  6: "Macros",
  7: "Pages"
};

