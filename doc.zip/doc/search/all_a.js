var searchData=
[
  ['rand_5fno',['rand_no',['../play_8c.html#ad0b41dc85361a90d21658e4cffbf02c8',1,'rand_no(int *pmin, int *pmax):&#160;play.c'],['../play_8h.html#ad0b41dc85361a90d21658e4cffbf02c8',1,'rand_no(int *pmin, int *pmax):&#160;play.c']]]
];
