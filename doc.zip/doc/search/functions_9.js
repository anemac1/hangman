var searchData=
[
  ['word_5freset',['word_reset',['../file__io_8c.html#a8f26ab291d11adef8fd9454b93eeb3bf',1,'word_reset(char *filename):&#160;file_io.c'],['../file__io_8h.html#a8f26ab291d11adef8fd9454b93eeb3bf',1,'word_reset(char *filename):&#160;file_io.c']]]
];
