var searchData=
[
  ['log_5fuser_5finput',['log_user_input',['../log_8c.html#ad471e3d741a81d5bac4f47e747f708bc',1,'log_user_input(char *filename, int switcher, char ch, char *word):&#160;log.c'],['../log_8h.html#ad471e3d741a81d5bac4f47e747f708bc',1,'log_user_input(char *filename, int switcher, char ch, char *word):&#160;log.c']]]
];
