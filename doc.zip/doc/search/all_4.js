var searchData=
[
  ['get_5fword',['get_word',['../play_8c.html#a74f6dacc217e136126e5d63bdc70df7d',1,'get_word(file_words_t list[]):&#160;play.c'],['../play_8h.html#a74f6dacc217e136126e5d63bdc70df7d',1,'get_word(file_words_t list[]):&#160;play.c']]]
];
