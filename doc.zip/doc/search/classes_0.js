var searchData=
[
  ['file_5fwords_5fs',['file_words_s',['../structfile__words__s.html',1,'']]]
];
