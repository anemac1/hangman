var searchData=
[
  ['maxchar',['maxchar',['../hangman_8h.html#a9d741e1b6e98646acb7ea89e9342c470',1,'hangman.h']]],
  ['maxwords',['maxwords',['../hangman_8h.html#a6ff48e7fb41d036609b08394605d4ebf',1,'hangman.h']]]
];
