var searchData=
[
  ['lfile',['lfile',['../hangman_8h.html#a22042cf466f9bf9e55657d344aad7b61',1,'hangman.h']]],
  ['log_2ec',['log.c',['../log_8c.html',1,'']]],
  ['log_2eh',['log.h',['../log_8h.html',1,'']]],
  ['log_5fuser_5finput',['log_user_input',['../log_8c.html#ad471e3d741a81d5bac4f47e747f708bc',1,'log_user_input(char *filename, int switcher, char ch, char *word):&#160;log.c'],['../log_8h.html#ad471e3d741a81d5bac4f47e747f708bc',1,'log_user_input(char *filename, int switcher, char ch, char *word):&#160;log.c']]]
];
