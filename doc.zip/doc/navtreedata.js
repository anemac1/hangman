var NAVTREE =
[
  [ "Hangman", "index.html", [
    [ "HSWE C project", "index.html", [
      [ "How to play", "index.html#sec1", [
        [ "Important: Using words from file!", "index.html#sec1_1", null ]
      ] ],
      [ "Features", "index.html#sec2", null ],
      [ "Parts", "index.html#sec3", [
        [ "Main (Hangman)", "index.html#sec3_1", null ],
        [ "Menu (and instructions)", "index.html#sec3_2", null ],
        [ "Play", "index.html#sec3_3", null ],
        [ "File_IO", "index.html#sec3_4", null ],
        [ "Logging", "index.html#sec3_5", null ]
      ] ],
      [ "Version Control", "index.html#sec4", null ]
    ] ],
    [ "Data Structures", "annotated.html", [
      [ "Data Structures", "annotated.html", "annotated_dup" ],
      [ "Data Structure Index", "classes.html", null ]
    ] ],
    [ "Files", null, [
      [ "File List", "files.html", "files" ],
      [ "Globals", "globals.html", [
        [ "All", "globals.html", null ],
        [ "Functions", "globals_func.html", null ],
        [ "Variables", "globals_vars.html", null ],
        [ "Enumerations", "globals_enum.html", null ],
        [ "Macros", "globals_defs.html", null ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"annotated.html"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';