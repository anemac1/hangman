var hangman_8c =
[
    [ "main", "hangman_8c.html#a0ddf1224851353fc92bfbff6f499fa97", null ],
    [ "main_cl", "hangman_8c.html#a5e20663a666b0df33875850ec3624902", null ],
    [ "main_m", "hangman_8c.html#ac4fb193ab29b47c2e6bf34e8fe85563b", null ]
];