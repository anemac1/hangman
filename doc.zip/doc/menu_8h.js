var menu_8h =
[
    [ "menu_s", "structmenu__s.html", "structmenu__s" ],
    [ "menu_t", "menu_8h.html#aed08c6d5d5b5d87ad2368f169239217c", null ],
    [ "parse_input", "menu_8h.html#a8ee469c782aa1a090e0b2b37ba1aec3e", null ],
    [ "set_file", "menu_8h.html#addd4cebbb808f9f838c4393d9597d249", null ],
    [ "show_instr", "menu_8h.html#a049ea0c5d3872ee8fd5961d9d0922447", null ],
    [ "show_menu", "menu_8h.html#af67480724089637b55a8148566870f16", null ]
];