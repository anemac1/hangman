var hangman_8h =
[
    [ "file_words_s", "structfile__words__s.html", "structfile__words__s" ],
    [ "D", "hangman_8h.html#af316c33cc298530f245e8b55330e86b5", null ],
    [ "dfile", "hangman_8h.html#ad9527987fcff04941182d5652b3c3d73", null ],
    [ "lfile", "hangman_8h.html#a22042cf466f9bf9e55657d344aad7b61", null ],
    [ "maxchar", "hangman_8h.html#a9d741e1b6e98646acb7ea89e9342c470", null ],
    [ "maxwords", "hangman_8h.html#a6ff48e7fb41d036609b08394605d4ebf", null ],
    [ "wguesses", "hangman_8h.html#ad2716bcb9d12d0c90a58499fea4a25dd", null ],
    [ "file_words_t", "hangman_8h.html#aaf21d390b440cc8ffa445d4d9d2078a7", null ]
];