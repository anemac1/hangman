var structmenu__s =
[
    [ "symbol", "structmenu__s.html#a616849d46d90c6c0792eade0ca01cb5d", null ],
    [ "text", "structmenu__s.html#ad2a8198c356cb83c0469c006e1b40713", null ]
];