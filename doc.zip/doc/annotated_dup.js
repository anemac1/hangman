var annotated_dup =
[
    [ "file_words_s", "structfile__words__s.html", "structfile__words__s" ],
    [ "menu_s", "structmenu__s.html", "structmenu__s" ]
];