var files =
[
    [ "file_io.c", "file__io_8c.html", "file__io_8c" ],
    [ "file_io.h", "file__io_8h.html", "file__io_8h" ],
    [ "hangman.c", "hangman_8c.html", "hangman_8c" ],
    [ "hangman.h", "hangman_8h.html", "hangman_8h" ],
    [ "log.c", "log_8c.html", "log_8c" ],
    [ "log.h", "log_8h.html", "log_8h" ],
    [ "menu.c", "menu_8c.html", "menu_8c" ],
    [ "menu.h", "menu_8h.html", "menu_8h" ],
    [ "play.c", "play_8c.html", "play_8c" ],
    [ "play.h", "play_8h.html", "play_8h" ]
];